// Fix BigInt serialization for JSON.stringify
(BigInt.prototype as any).toJSON = function () {
  return Number(this);
};

import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Sidebar } from "@/components/sidebar";
import { MobileSidebar } from "@/components/mobile-sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { DbProvider } from "@/components/providers/db-provider";
import { GlobalReminder } from "@/components/global-reminder";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#000000",
};

export const metadata: Metadata = {
  title: "Cordinal Mushrooms",
  description: "Facility Management System",
  appleWebApp: {
    capable: true,
    title: "Cordinal",
    statusBarStyle: "default",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="flex font-sans h-screen bg-background">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
          themes={['light', 'dark', 'nature', 'cordyceps', 'midnight']}
        >
          <DbProvider>
            <div className="flex h-screen w-full flex-col md:flex-row bg-background">
              {/* Desktop Sidebar */}
              <Sidebar />

              {/* Mobile Sidebar (Header) */}
              <MobileSidebar />

              <main className="flex-1 overflow-y-auto p-4 md:p-8">
                {children}
              </main>
            </div>
            {/* Run global logic logic components inside DbProvider */}
            <GlobalReminder />
          </DbProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
