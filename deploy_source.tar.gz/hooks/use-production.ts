import { saveDatabase } from "@/lib/db/client";
import { useDb } from "@/components/providers/db-provider";
import { useCallback } from "react";
import {
    startBatchService,
    harvestBatchService,
    discardBatchService,
    deleteBatchService,
    updateBatchService,
    logBatchActionService,
    discardPartialBatchService,
    updateBatchNotesService
} from "@/lib/services/production";

export function useProduction() {
    const { db } = useDb();

    const startBatch = useCallback(async (formData: FormData | any) => {
        if (!db) throw new Error("Database not initialized");

        const get = (key: string) => {
            if (formData instanceof FormData) return formData.get(key);
            return formData[key];
        }

        const name = get("name") as string;
        const type = get("type") as string;
        const sourceId = get("sourceId") as string;
        const startDate = get("startDate") as string;
        const rackId = Number(get("rackId"));
        const jarCount = Number(get("jarCount"));
        const locationsStr = get("locations") as string;
        const providedLayer = Number(get("layer"));
        const notes = get("notes") as string || null;
        const motherCultureSource = get("motherCultureSource") as string || "New";

        const res = await startBatchService(db, {
            name, type, sourceId, startDate, rackId, jarCount, locationsStr, providedLayer, notes, motherCultureSource
        });

        await saveDatabase();
        return res;
    }, [db]);

    const harvestBatch = useCallback(async (batchId: number) => {
        if (!db) return;
        await harvestBatchService(db, batchId);
        await saveDatabase();
    }, [db]);

    const discardBatch = useCallback(async (batchId: number) => {
        if (!db) return;
        await discardBatchService(db, batchId);
        await saveDatabase();
    }, [db]);

    const deleteBatch = useCallback(async (id: number) => {
        if (!db) return;
        await deleteBatchService(db, id);
        await saveDatabase();
    }, [db]);

    const discardPartialBatch = useCallback(async (batchId: number, rackId: number, layer: number, quantity: number) => {
        if (!db) return;
        await discardPartialBatchService(db, batchId, rackId, layer, quantity);
        await saveDatabase();
    }, [db]);

    const updateBatch = useCallback(async (formData: FormData | any) => {
        if (!db) return;
        const get = (key: string) => (formData instanceof FormData ? formData.get(key) : formData[key]);

        await updateBatchService(db, {
            id: Number(get("id")),
            name: get("name") as string,
            sourceId: get("sourceId") as string,
            startDate: get("startDate") as string,
            jarCount: Number(get("jarCount")),
            status: get("status") as string
        });
        await saveDatabase();
    }, [db]);

    const logBatchAction = useCallback(async (batchId: number, actionType: string) => {
        if (!db) return;
        await logBatchActionService(db, batchId, actionType);
        await saveDatabase();
    }, [db]);

    const updateBatchNotes = useCallback(async (batchId: number, notes: string) => {
        if (!db) return;
        await updateBatchNotesService(db, batchId, notes);
        await saveDatabase();
    }, [db]);

    const getAvailableSourceJars = useCallback(async (type: string) => {
        if (!db) return [];
        // If type is "Jars", we need "Liquid Culture" jars
        const requiredBatchType = type === "Jars" ? "Liquid Culture" : null;
        if (!requiredBatchType) return [];

        const { batches, batchJars } = await import("@/lib/db/schema");
        const { eq, and, not } = await import("drizzle-orm");

        const result = await db.select({
            jarId: batchJars.id,
            batchName: batches.name,
            jarIndex: batchJars.jarIndex,
            status: batchJars.status
        })
        .from(batchJars)
        .leftJoin(batches, eq(batchJars.batchId, batches.id))
        .where(
            and(
                eq(batches.type, requiredBatchType),
                not(eq(batchJars.status, "Discarded"))
            )
        )
        .orderBy(batches.name, batchJars.jarIndex);

        return result;
    }, [db]);

    return { startBatch, updateBatch, updateBatchNotes, harvestBatch, discardBatch, deleteBatch, logBatchAction, discardPartialBatch, getAvailableSourceJars };
}
